import re
from io import BytesIO
from pathlib import Path
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_TAB_ALIGNMENT, WD_TAB_LEADER
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

NAVY = "17365D"
BLUE = "2F75B5"
LIGHT = "D9EAF7"
GREY = "666666"
STATUS_COLORS = {"Approved": "2E7D32", "Changes Requested": "C62828"}
DEFAULT_STATUS_COLOR = "9A6700"
FIG_DIR = Path(__file__).parent / "data" / "figures"


def fmt_date(value, default="Pending"):
    """'2026-11-22' or '2026-11-22 14:05' -> '22-Nov-2026'."""
    if not value:
        return default
    try:
        return datetime.strptime(str(value)[:10], "%Y-%m-%d").strftime("%d-%b-%Y")
    except ValueError:
        return str(value)


def shade(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:fill"), fill)
    tcPr.append(shd)


def set_cell_text(cell, text, bold=False, color=None, size=9, align=None):
    cell.text = ""
    p = cell.paragraphs[0]
    if align:
        p.alignment = align
    r = p.add_run(str(text) if text else "")
    r.bold = bold
    if color:
        r.font.color.rgb = RGBColor.from_string(color)
    r.font.size = Pt(size)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def add_field_table(doc, rows):
    table = doc.add_table(rows=0, cols=2)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    for label, value in rows:
        cells = table.add_row().cells
        set_cell_text(cells[0], label, True, NAVY)
        shade(cells[0], LIGHT)
        set_cell_text(cells[1], value or "[To be completed]")
    doc.add_paragraph()


def add_table(doc, headers, rows, widths=None):
    """Table with a navy header row. Empty values show an em dash."""
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        set_cell_text(table.rows[0].cells[i], h, True, "FFFFFF")
        shade(table.rows[0].cells[i], NAVY)
    for row in rows:
        cells = table.add_row().cells
        for i, v in enumerate(row):
            set_cell_text(cells[i], v if v else "—", bold=(i == 0))
    if widths:
        for row in table.rows:
            for i, w in enumerate(widths):
                row.cells[i].width = Inches(w)
    doc.add_paragraph()


def add_section(doc, hd, title, content=None, prompt=None):
    hd(title)
    if content and str(content).strip():
        for line in str(content).splitlines():
            if line.strip():
                p = doc.add_paragraph()
                p.paragraph_format.space_after = Pt(4)
                p.add_run(line.strip())
    else:
        p = doc.add_paragraph()
        r = p.add_run(prompt or "[Enter information here]")
        r.italic = True
        r.font.color.rgb = RGBColor(120, 120, 120)


def add_requirements_table(doc, hd, title, raw, prefix, prompt):
    hd(title)
    lines = [x.strip() for x in (raw or "").splitlines() if x.strip()]
    if not lines:
        doc.add_paragraph(prompt)
        return
    table = doc.add_table(rows=1, cols=3)
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(["ID", "Requirement", "Priority"]):
        set_cell_text(table.rows[0].cells[i], h, True, "FFFFFF")
        shade(table.rows[0].cells[i], NAVY)
    for idx, line in enumerate(lines, 1):
        cells = table.add_row().cells
        set_cell_text(cells[0], f"{prefix}-{idx:02d}")
        set_cell_text(cells[1], line)
        set_cell_text(cells[2], "[High / Medium / Low]")
    doc.add_paragraph()


def add_status_banner(doc, status):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = table.rows[0].cells[0]
    shade(cell, STATUS_COLORS.get(status, DEFAULT_STATUS_COLOR))
    set_cell_text(cell, f"FINAL STATUS: {status.upper()}", True, "FFFFFF", size=12,
                  align=WD_ALIGN_PARAGRAPH.CENTER)
    doc.add_paragraph()


def add_control_section(doc, hd, data, c):
    """DOCUMENT CONTROL & APPROVAL, filled automatically from the workflow."""
    hd("DOCUMENT CONTROL & APPROVAL")
    p = doc.add_paragraph()
    r = p.add_run("SOFTWARE REQUIREMENTS DOCUMENT")
    r.bold = True
    r.font.size = Pt(9)
    r.font.color.rgb = RGBColor.from_string(GREY)

    add_table(doc, ["Document information", "Details"], [
        ("Project Name", data.get("project_name")),
        ("Document ID", c["doc_id"]),
        ("Version", c["version"]),
        ("Created Date", fmt_date(c["created_date"], "—")),
        ("Document Status", c["status"]),
    ], widths=[2.4, 4.4])

    hd("Document Ownership", 2, toc=False)
    add_table(doc, ["Role", "Name", "Date"], [
        ("Prepared By", c["prepared_by"] or "Not assigned", fmt_date(c["prepared_date"])),
        ("Reviewed By", c["reviewer"] or "Not assigned", fmt_date(c["reviewer_date"])),
        ("Approved By", c["approver"] or "Not assigned", fmt_date(c["approver_date"])),
    ], widths=[2.0, 3.0, 1.8])

    hd("Review and Approval Record", 2, toc=False)
    add_table(doc, ["Stage", "Decision", "Comments"], [
        ("Review", c["review_decision"] or "Pending", c["review_comments"]),
        ("Final Approval", c["approval_decision"] or "Pending", c["approval_comments"]),
    ], widths=[1.6, 1.6, 3.6])

    if c.get("history"):
        hd("Version History", 2, toc=False)
        add_table(doc, ["Version", "Reviewer", "Approver", "Status"],
                  [(h["version"], h["reviewer"], h["approver"], h["status"]) for h in c["history"]],
                  widths=[1.0, 2.0, 2.0, 1.8])

    add_status_banner(doc, c["status"])


def _r(text=None, bold=False, size=10, color=None):
    r = OxmlElement("w:r")
    rPr = OxmlElement("w:rPr")
    if bold:
        rPr.append(OxmlElement("w:b"))
    if color:
        col = OxmlElement("w:color")
        col.set(qn("w:val"), color)
        rPr.append(col)
    sz = OxmlElement("w:sz")
    sz.set(qn("w:val"), str(int(size * 2)))
    rPr.append(sz)
    r.append(rPr)
    if text is not None:
        t = OxmlElement("w:t")
        t.text = text
        t.set(qn("xml:space"), "preserve")
        r.append(t)
    return r


def _fld(kind):
    r = _r()
    fc = OxmlElement("w:fldChar")
    fc.set(qn("w:fldCharType"), kind)
    r.append(fc)
    return r


def _instr(text):
    r = _r()
    it = OxmlElement("w:instrText")
    it.set(qn("xml:space"), "preserve")
    it.text = text
    r.append(it)
    return r


def _simple_field(instr, cached, size=8, color=GREY):
    f = OxmlElement("w:fldSimple")
    f.set(qn("w:instr"), f" {instr} ")
    f.append(_r(cached, size=size, color=color))
    return f


def parse_glossary(raw):
    items = []
    for line in (raw or "").splitlines():
        line = line.strip()
        if not line:
            continue
        term, sep, definition = line.partition(":")
        items.append((term.strip(), definition.strip() if sep and definition.strip() else "[Definition to be added]"))
    return sorted(items, key=lambda x: x[0].lower())


class _Builder:
    """Keeps track of headings / figures so the TOC and List of Figures can link to them."""

    def __init__(self, doc, page_map):
        self.doc = doc
        self.page_map = page_map or {}
        self.toc = []      # (level, text, bookmark)
        self.figs = []     # (text, bookmark)
        self.bid = 0
        self.marker = None

    def _bookmark(self, paragraph, name):
        self.bid += 1
        start = OxmlElement("w:bookmarkStart")
        start.set(qn("w:id"), str(self.bid))
        start.set(qn("w:name"), name)
        end = OxmlElement("w:bookmarkEnd")
        end.set(qn("w:id"), str(self.bid))
        p = paragraph._p
        pPr = p.pPr
        p.insert(list(p).index(pPr) + 1 if pPr is not None else 0, start)
        p.append(end)

    def heading(self, text, level=None, toc=True):
        if level is None:
            level = 2 if re.match(r"^\d+\.\d+\s", text) else 1
        p = self.doc.add_heading(text, level=level)
        if toc:
            name = f"_Toc{len(self.toc) + 1:04d}"
            self._bookmark(p, name)
            self.toc.append((level, text, name))
        return p

    def _place(self, paragraph):
        self.marker._p.addprevious(paragraph._p)

    def _title(self, text):
        p = self.doc.add_paragraph()
        p.paragraph_format.space_before = Pt(6)
        p.paragraph_format.space_after = Pt(8)
        run = p.add_run(text)
        run.bold = True
        run.font.size = Pt(15)
        run.font.color.rgb = RGBColor.from_string(NAVY)
        self._place(p)

    def _entry(self, text, name, level=1):
        p = self.doc.add_paragraph()
        pf = p.paragraph_format
        pf.left_indent = Inches(0.3 * (level - 1))
        pf.space_after = Pt(3)
        pf.tab_stops.add_tab_stop(Inches(6.9), WD_TAB_ALIGNMENT.RIGHT, WD_TAB_LEADER.DOTS)
        link = OxmlElement("w:hyperlink")
        link.set(qn("w:anchor"), name)
        link.set(qn("w:history"), "1")
        link.append(_r(text, bold=(level == 1), color=NAVY))
        tab = _r(color=NAVY)
        tab.append(OxmlElement("w:tab"))
        link.append(tab)
        page = self.page_map.get(name)
        for el in (_fld("begin"), _instr(f" PAGEREF {name} \\h "), _fld("separate"),
                   _r(str(page) if page else "–", color=NAVY), _fld("end")):
            link.append(el)
        p._p.append(link)
        self._place(p)

    def front_matter(self):
        self._title("TABLE OF CONTENTS")
        for level, text, name in self.toc:
            self._entry(text, name, level)
        p = self.doc.add_paragraph()
        self._place(p)
        self._title("LIST OF FIGURES")
        if not self.figs:
            p = self.doc.add_paragraph()
            r = p.add_run("No figures have been added to this document.")
            r.italic = True
            r.font.color.rgb = RGBColor(120, 120, 120)
            self._place(p)
        for text, name in self.figs:
            self._entry(text, name, 1)

    def figures_section(self, figures):
        doc = self.doc
        self.heading("10. Figures and Diagrams")
        shown = 0
        for fig in figures or []:
            path = FIG_DIR / str(fig.get("file", ""))
            if not path.is_file():
                continue
            shown += 1
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.keep_with_next = True
            pic = p.add_run().add_picture(str(path))
            scale = min(1.0, Inches(6.3) / pic.width, Inches(6.5) / pic.height)
            pic.width, pic.height = int(pic.width * scale), int(pic.height * scale)
            text = f"Figure {shown}: {(fig.get('caption') or 'Untitled figure').strip()}"
            cap = doc.add_paragraph(style="Caption")
            cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
            cap.add_run(text)
            name = f"_Fig{shown:04d}"
            self._bookmark(cap, name)
            self.figs.append((text, name))
        if not shown:
            p = doc.add_paragraph()
            r = p.add_run("[Add diagrams, screen mock-ups or process flows here. Each figure is listed in the List of Figures.]")
            r.italic = True
            r.font.color.rgb = RGBColor(120, 120, 120)

    def glossary_section(self, raw):
        self.heading("11. Glossary")
        items = parse_glossary(raw)
        if not items:
            p = self.doc.add_paragraph()
            r = p.add_run("[Define abbreviations and technical terms used in this document.]")
            r.italic = True
            r.font.color.rgb = RGBColor(120, 120, 120)
            return
        add_table(self.doc, ["Term", "Definition"], items, widths=[1.8, 5.0])


def build_srd_ex(data, control=None, page_map=None):
    c = {
        "doc_id": "Not assigned", "version": data.get("version") or "0.1", "status": "Draft",
        "created_date": data.get("project_date", ""), "prepared_by": data.get("prepared_by", ""),
        "prepared_date": data.get("project_date", ""), "reviewer": None, "reviewer_date": None,
        "approver": None, "approver_date": None, "review_decision": None, "review_comments": None,
        "approval_decision": None, "approval_comments": None, "history": [],
    }
    c.update(control or {})

    doc = Document()
    b = _Builder(doc, page_map)
    hd = b.heading
    section = doc.sections[0]
    section.top_margin = Inches(0.7)
    section.bottom_margin = Inches(0.7)
    section.left_margin = Inches(0.8)
    section.right_margin = Inches(0.8)

    styles = doc.styles
    styles["Normal"].font.name = "Aptos"
    styles["Normal"].font.size = Pt(10)
    styles["Normal"].font.color.rgb = RGBColor(45, 55, 65)
    for style_name in ["Heading 1", "Heading 2"]:
        styles[style_name].font.name = "Aptos Display"
        styles[style_name].font.color.rgb = RGBColor.from_string(NAVY)
    styles["Heading 1"].font.size = Pt(15)
    styles["Heading 1"].font.bold = True
    styles["Heading 2"].font.size = Pt(12)

    header = section.header.paragraphs[0]
    header.text = f"SOFTWARE REQUIREMENTS DOCUMENT  |  {c['doc_id']}  |  v{c['version']}  |  {c['status'].upper()}"
    header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    for run in header.runs:
        run.font.size = Pt(8)
        run.font.color.rgb = RGBColor.from_string(GREY)
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer._p.append(_r("Controlled business document • Generated by Smart SRD Builder   |   Page ", size=8, color=GREY))
    footer._p.append(_simple_field("PAGE", "1"))
    footer._p.append(_r(" of ", size=8, color=GREY))
    footer._p.append(_simple_field("NUMPAGES", "1"))

    # Ask Word to refresh page numbers / TOC when the file is opened
    upd = OxmlElement("w:updateFields")
    upd.set(qn("w:val"), "true")
    settings = doc.settings.element
    anchor = settings.find(qn("w:characterSpacingControl"))
    if anchor is not None:
        anchor.addnext(upd)
    else:
        settings.append(upd)

    # Cover
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(75)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("SOFTWARE REQUIREMENTS\nDOCUMENT")
    r.bold = True
    r.font.size = Pt(25)
    r.font.color.rgb = RGBColor.from_string(NAVY)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(data.get("project_name") or "[Project Name]")
    r.bold = True
    r.font.size = Pt(19)
    r.font.color.rgb = RGBColor.from_string(BLUE)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run(f"{c['doc_id']}  •  Version {c['version']}").font.size = Pt(11)
    doc.add_paragraph()
    add_field_table(doc, [
        ("Department", data.get("department")),
        ("Project owner", data.get("project_owner")),
        ("Prepared by", c["prepared_by"]),
        ("Document date", fmt_date(data.get("project_date"), "")),
        ("Target completion", fmt_date(data.get("target_date"), "")),
        ("Document status", c["status"]),
    ])
    doc.add_page_break()

    # Document Control & Approval (immediately after the cover page)
    add_control_section(doc, hd, data, c)
    doc.add_page_break()

    # Table of Contents + List of Figures are filled in at the end (marker = where they go)
    b.marker = doc.add_paragraph()
    b.marker.add_run().add_break(WD_BREAK.PAGE)

    hd("1. Introduction")
    add_section(doc, hd, "1.1 Project Overview", data.get("description"),
                "[Describe the project, the current situation and the proposed solution.]")
    add_section(doc, hd, "1.2 Business Need / Problem Statement", data.get("business_need"),
                "[Explain the business problem or opportunity this project addresses.]")
    add_section(doc, hd, "1.3 Project Objectives", data.get("objectives"),
                "[List measurable objectives. Use one objective per line.]")

    hd("2. Stakeholders")
    add_field_table(doc, [
        ("Key stakeholders", data.get("stakeholders")),
        ("Project owner / sponsor", data.get("project_owner")),
        ("Department", data.get("department")),
    ])

    hd("3. Project Scope")
    add_section(doc, hd, "3.1 In Scope", data.get("scope_in"), "[List features, processes and activities included in this project.]")
    add_section(doc, hd, "3.2 Out of Scope", data.get("scope_out"), "[List items explicitly excluded from this project.]")

    add_requirements_table(doc, hd, "4. Functional Requirements",
                           data.get("functional_requirements"), "FR",
                           "[Add functional requirements. Describe what the system must do, preferably one requirement per line.]")
    add_requirements_table(doc, hd, "5. Non-Functional Requirements",
                           data.get("nonfunctional_requirements"), "NFR",
                           "[Add quality requirements such as security, performance, availability, accessibility and usability.]")

    add_section(doc, hd, "6. Assumptions", data.get("assumptions"), "[List assumptions on which the project is based.]")
    add_section(doc, hd, "7. Dependencies", data.get("dependencies"), "[List systems, teams, vendors, data or approvals this project depends on.]")
    add_section(doc, hd, "8. Risks and Constraints", data.get("risks"), "[Describe known risks, limitations and constraints.]")
    add_section(doc, hd, "9. Acceptance Criteria", data.get("acceptance"), "[Define measurable conditions that must be met for the solution to be accepted.]")

    b.figures_section(data.get("figures"))
    b.glossary_section(data.get("glossary"))
    b.front_matter()

    note = doc.add_paragraph()
    run = note.add_run("Guidance: Replace all bracketed prompts with approved project information. "
                       "Validate AI-suggested content with the relevant stakeholders before sign-off.")
    run.italic = True
    run.font.size = Pt(8)
    run.font.color.rgb = RGBColor.from_string(GREY)

    output = BytesIO()
    doc.save(output)
    entries = [name for _, _, name in b.toc] + [name for _, name in b.figs]
    return output.getvalue(), entries


def build_srd(data, control=None, page_map=None):
    return build_srd_ex(data, control, page_map)[0]

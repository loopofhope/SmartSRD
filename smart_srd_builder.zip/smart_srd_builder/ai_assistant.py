import json
import urllib.request
import urllib.error

OLLAMA_URL = "http://localhost:11434"
DEFAULT_MODEL = "llama3.2"

def check_ollama():
    try:
        with urllib.request.urlopen(f"{OLLAMA_URL}/api/tags", timeout=1.5) as response:
            payload = json.loads(response.read().decode("utf-8"))
        models = [m.get("name", "") for m in payload.get("models", [])]
        if not models:
            return False, "Ollama is running, but no model is installed. See README for setup."
        return True, "Installed models: " + ", ".join(models[:4])
    except Exception:
        return False, "Install Ollama and pull a model to enable offline AI. Core document generation works without AI."

def _generate(prompt, model=None):
    model = model or DEFAULT_MODEL
    body = json.dumps({
        "model": model,
        "prompt": prompt,
        "stream": False,
        "options": {"temperature": 0.25}
    }).encode("utf-8")
    req = urllib.request.Request(
        f"{OLLAMA_URL}/api/generate", data=body,
        headers={"Content-Type": "application/json"}, method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as response:
            result = json.loads(response.read().decode("utf-8"))
        return result.get("response", "").strip(), None
    except urllib.error.URLError as exc:
        return None, f"Could not connect to Ollama: {exc}. Check that Ollama is running and a model is installed."
    except Exception as exc:
        return None, f"AI request failed: {exc}"

def enhance_description(description, project_name):
    if not description.strip():
        return None, "Enter a short project description first."
    prompt = f"""Rewrite the following as a clear, professional project overview for an internal Software Requirements Document.
Do not invent facts, scope, systems, metrics or stakeholders. Preserve the original meaning. Return only the improved paragraph.
Project: {project_name}
Description: {description}"""
    result, error = _generate(prompt)
    return (result, "Description enhanced using local AI.") if result else (None, error)

def suggest_requirements(data, kind):
    desc = data.get("description", "").strip()
    objective = data.get("objectives", "").strip()
    if not desc and not objective:
        return None, "Enter a project description or objective first."
    if kind == "functional":
        instruction = "Suggest 5-8 functional requirements describing what the solution should do."
        prefix = "FR"
    else:
        instruction = "Suggest 5-8 non-functional requirements about security, performance, usability, availability, maintainability or accessibility, only where relevant."
        prefix = "NFR"
    prompt = f"""You are helping draft an internal Software Requirements Document.
{instruction}
Project: {data.get('project_name','')}
Description: {desc}
Objectives: {objective}
Rules:
- Do not claim these are confirmed requirements.
- Do not invent specific integrations, technologies, numeric targets or policies.
- Phrase each item as a testable 'The system shall...' statement where possible.
- Return one requirement per line, without numbering or commentary.
- Keep suggestions generic when project details are missing."""
    result, error = _generate(prompt)
    if result:
        lines = [line.strip().lstrip("-•0123456789. ") for line in result.splitlines() if line.strip()]
        return "\n".join(lines), f"Local AI suggested {prefix} items. Review and edit before including them."
    return None, error

"""Show the real Word document in the browser.

The .docx is converted to PDF (Microsoft Word via docx2pdf on Windows, otherwise LibreOffice if
installed) and each PDF page is displayed as an image, so reviewers see exactly the document
that will be downloaded. Download buttons for .docx and .pdf are shown above the pages.
"""
import os
import base64
import shutil
import subprocess
import tempfile
from pathlib import Path

import streamlit as st
import streamlit.components.v1 as components

DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
LIBREOFFICE_PATHS = (
    r"C:\Program Files\LibreOffice\program\soffice.exe",
    r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
)


def _soffice():
    for name in ("soffice", "libreoffice"):
        found = shutil.which(name)
        if found:
            return found
    for path in LIBREOFFICE_PATHS:
        if os.path.exists(path):
            return path
    return None


def docx_to_pdf(docx_bytes):
    """Return (pdf_bytes, None) or (None, error_message)."""
    errors = []
    with tempfile.TemporaryDirectory() as tmp:
        src, out = Path(tmp) / "doc.docx", Path(tmp) / "doc.pdf"
        src.write_bytes(docx_bytes)

        if os.name == "nt":  # Microsoft Word, if installed
            try:
                import pythoncom
                pythoncom.CoInitialize()
                try:
                    from docx2pdf import convert
                    convert(str(src), str(out))
                finally:
                    pythoncom.CoUninitialize()
                if out.exists():
                    return out.read_bytes(), None
            except Exception as exc:
                errors.append(f"Word: {exc}")

        exe = _soffice()
        if exe:
            try:
                subprocess.run([exe, "--headless", "--convert-to", "pdf", "--outdir", tmp, str(src)],
                               check=True, timeout=120, capture_output=True)
                if out.exists():
                    return out.read_bytes(), None
            except Exception as exc:
                errors.append(f"LibreOffice: {exc}")
        else:
            errors.append("LibreOffice not found")
    return None, "; ".join(errors)


try:
    import pymupdf as fitz
except ImportError:  # older PyMuPDF
    import fitz


@st.cache_data(show_spinner="Preparing document view…", ttl=900)
def _pdf_for(docx_bytes):
    return docx_to_pdf(docx_bytes)


def _page_map(pdf_bytes, entries):
    """Read the TOC / figure-list links in the PDF to learn which page each bookmark lands on."""
    rows = []
    with fitz.open(stream=pdf_bytes, filetype="pdf") as pdf:
        for pno, page in enumerate(pdf):
            for link in page.get_links():
                if link.get("kind") == fitz.LINK_GOTO and "page" in link:
                    rows.append((pno, round(link["from"].y0 / 3), link["page"]))
    lines, seen = [], set()
    for pno, row, target in sorted(rows):  # one entry per text line (a link can be split into pieces)
        if (pno, row) not in seen:
            seen.add((pno, row))
            lines.append(target + 1)
    return dict(zip(entries, lines)) if len(lines) == len(entries) else {}


@st.cache_data(show_spinner="Preparing document…", ttl=900)
def build_paged(data, control):
    """Build the .docx; if a converter exists, fill the TOC / figure list with real page numbers."""
    from srd_generator import build_srd, build_srd_ex
    first, entries = build_srd_ex(data, control)
    pdf, _ = _pdf_for(first)
    if not pdf or not entries:
        return first
    page_map = _page_map(pdf, entries)
    return build_srd(data, control, page_map=page_map) if page_map else first


@st.cache_data(show_spinner=False, ttl=900)
def _viewer_html(pdf_bytes):
    """Pages as images with invisible click areas on every internal link (TOC, figure list)."""
    pages = []
    with fitz.open(stream=pdf_bytes, filetype="pdf") as pdf:
        for pno, page in enumerate(pdf):
            png = base64.b64encode(page.get_pixmap(dpi=110).tobytes("png")).decode()
            sx, sy = 100 / page.rect.width, 100 / page.rect.height
            links = ""
            for link in page.get_links():
                if link.get("kind") == fitz.LINK_GOTO and "page" in link:
                    r = link["from"]
                    links += (f'<a title="Go to page {link["page"] + 1}" onclick="go({link["page"]})" '
                              f'style="left:{r.x0 * sx:.2f}%;top:{r.y0 * sy:.2f}%;'
                              f'width:{(r.x1 - r.x0) * sx:.2f}%;height:{(r.y1 - r.y0) * sy:.2f}%"></a>')
            pages.append(f'<div class="pg" id="p{pno}"><img src="data:image/png;base64,{png}"/>{links}'
                         f'<div class="no">Page {pno + 1} of {len(pdf)}</div></div>')
    return ("<style>body{margin:0;background:#e8ecf1;font-family:sans-serif}"
            ".pg{position:relative;max-width:820px;margin:12px auto;background:#fff;box-shadow:0 1px 6px #0004}"
            ".pg img{width:100%;display:block}.pg a{position:absolute;cursor:pointer}"
            ".pg a:hover{background:rgba(47,117,181,.20)}.no{text-align:center;font-size:11px;color:#667;padding:3px}"
            "</style><script>function go(n){document.getElementById('p'+n).scrollIntoView({behavior:'smooth'})}"
            "</script>" + "".join(pages))


def render_document(docx_bytes, key, base_name):
    """Show download buttons plus the document pages. Returns False if the view could not be built."""
    pdf, error = _pdf_for(docx_bytes)
    c1, c2 = st.columns(2)
    c1.download_button("⬇ Download Word (.docx)", docx_bytes, file_name=f"{base_name}.docx",
                       mime=DOCX_MIME, key=f"{key}_docx", width="stretch")
    if not pdf:
        c2.empty()
        st.warning("Could not show the document in the browser (a converter is needed): "
                   f"{error}. Install LibreOffice (free) or use a PC with Microsoft Word, then restart the app. "
                   "Showing a simplified view instead.")
        return False
    c2.download_button("⬇ Download PDF", pdf, file_name=f"{base_name}.pdf", mime="application/pdf",
                       key=f"{key}_pdf", width="stretch")
    try:
        html = _viewer_html(pdf)
    except Exception as exc:
        st.warning(f"Could not draw the pages ({exc}). Use the PDF download instead.")
        return False
    st.caption("Tip: click any entry in the Table of Contents or List of Figures to jump to that page.")
    if hasattr(st, "iframe"):  # newer Streamlit; HTML here is generated from our own PDF only
        st.iframe(html, height=800)
    else:
        components.html(html, height=800, scrolling=True)
    return True

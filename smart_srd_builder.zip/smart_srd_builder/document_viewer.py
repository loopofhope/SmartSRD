"""Read-only preview of an SRD, shown to reviewers and approvers."""
import streamlit as st

from srd_generator import fmt_date


def _block(title, text, empty="Not provided"):
    st.markdown(f"**{title}**")
    if text and str(text).strip():
        for line in str(text).splitlines():
            if line.strip():
                st.write(line.strip())
    else:
        st.caption(empty)


def _requirements(title, raw, prefix):
    st.markdown(f"**{title}**")
    lines = [x.strip() for x in (raw or "").splitlines() if x.strip()]
    if not lines:
        st.caption("Not provided")
        return
    st.table([{"ID": f"{prefix}-{i:02d}", "Requirement": line} for i, line in enumerate(lines, 1)])


def render_preview(data, control):
    """Display the document content and its control block without any editing widgets."""
    st.markdown(f"## {data.get('project_name', 'Untitled')}")
    a, b, c = st.columns(3)
    a.metric("Document ID", control["doc_id"])
    b.metric("Version", control["version"])
    c.metric("Status", control["status"])

    with st.container(border=True):
        st.markdown("#### Document control")
        st.table([
            {"Role": "Prepared by", "Name": control["prepared_by"] or "—", "Date": fmt_date(control["prepared_date"])},
            {"Role": "Reviewed by", "Name": control["reviewer"] or "—", "Date": fmt_date(control["reviewer_date"])},
            {"Role": "Approved by", "Name": control["approver"] or "—", "Date": fmt_date(control["approver_date"])},
        ])
        st.table([
            {"Stage": "Review", "Decision": control["review_decision"] or "Pending",
             "Comments": control["review_comments"] or "—"},
            {"Stage": "Final Approval", "Decision": control["approval_decision"] or "Pending",
             "Comments": control["approval_comments"] or "—"},
        ])
        if control.get("history"):
            st.caption("Version history")
            st.table([{"Version": h["version"], "Reviewer": h["reviewer"], "Approver": h["approver"],
                       "Status": h["status"]} for h in control["history"]])

    with st.container(border=True):
        st.markdown("#### 1. Introduction")
        meta = [("Department", data.get("department")), ("Project owner", data.get("project_owner")),
                ("Key stakeholders", data.get("stakeholders")),
                ("Target completion", fmt_date(data.get("target_date"), ""))]
        for label, value in meta:
            if value:
                st.write(f"**{label}:** {value}")
        _block("Project overview", data.get("description"))
        _block("Business need / problem statement", data.get("business_need"))
        _block("Project objectives", data.get("objectives"))

    with st.container(border=True):
        st.markdown("#### 2. Scope")
        _block("In scope", data.get("scope_in"))
        _block("Out of scope", data.get("scope_out"))

    with st.container(border=True):
        st.markdown("#### 3. Requirements")
        _requirements("Functional requirements", data.get("functional_requirements"), "FR")
        _requirements("Non-functional requirements", data.get("nonfunctional_requirements"), "NFR")

    with st.container(border=True):
        st.markdown("#### 4. Other sections")
        _block("Assumptions", data.get("assumptions"))
        _block("Dependencies", data.get("dependencies"))
        _block("Risks and constraints", data.get("risks"))
        _block("Acceptance criteria", data.get("acceptance"))
        figs = [f.get("caption", "") for f in data.get("figures", [])]
        _block("Figures", "\n".join(f"Figure {i}: {c}" for i, c in enumerate(figs, 1)), "No figures added")
        _block("Glossary", data.get("glossary"))

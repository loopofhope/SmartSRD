"""Workflow engine for Smart SRD Builder.

Handles users, document records, versions, review / approval decisions and
status transitions. Everything is stored in data/projects.json and
data/users.json (no database needed).

Status flow:
    Draft -> In Review -> In Approval -> Approved
                 |             |
                 +-------------+--> Changes Requested -> (author edits) Draft -> resubmit (new version)
"""
import copy
import json
from datetime import datetime
from pathlib import Path

DATA_DIR = Path(__file__).parent / "data"
DATA_DIR.mkdir(exist_ok=True)
DOCS_FILE = DATA_DIR / "projects.json"
USERS_FILE = DATA_DIR / "users.json"

DRAFT = "Draft"
IN_REVIEW = "In Review"
IN_APPROVAL = "In Approval"
CHANGES = "Changes Requested"
APPROVED = "Approved"
LEGACY = "Generated (legacy)"

EDITABLE = {DRAFT, CHANGES}
APPROVE = "Approved"
REQUEST_CHANGES = "Changes Requested"

# Placeholder users for the prototype. Edit data/users.json or use the sidebar to add people.
DEFAULT_USERS = [
    {"name": "Aishwarya", "title": "Project Engineer"},
    {"name": "Ramesh", "title": "Manager"},
    {"name": "Uttam Singh", "title": "DGM"},
]


class WorkflowError(Exception):
    """Raised for invalid workflow actions (shown to the user as a message)."""


def _now():
    return datetime.now().strftime("%Y-%m-%d %H:%M")


# ---------------------------------------------------------------- users
def load_users():
    try:
        if USERS_FILE.exists():
            users = json.loads(USERS_FILE.read_text(encoding="utf-8"))
            if users:
                return users
    except Exception:
        pass
    USERS_FILE.write_text(json.dumps(DEFAULT_USERS, indent=2), encoding="utf-8")
    return list(DEFAULT_USERS)


def add_user(name, title=""):
    name = (name or "").strip()
    if not name:
        raise WorkflowError("Enter a name.")
    users = load_users()
    if any(u["name"].lower() == name.lower() for u in users):
        raise WorkflowError(f"{name} already exists.")
    users.append({"name": name, "title": (title or "").strip()})
    USERS_FILE.write_text(json.dumps(users, indent=2), encoding="utf-8")


# ---------------------------------------------------------------- storage
def load_docs():
    try:
        raw = json.loads(DOCS_FILE.read_text(encoding="utf-8")) if DOCS_FILE.exists() else []
    except Exception:
        raw = []
    docs = []
    for item in raw:
        if "versions" not in item:  # record written by the earlier prototype
            item = {
                "doc_id": "LEGACY-" + str(item.get("id", "")),
                "project_name": item.get("project_name", "Untitled"),
                "department": item.get("department", ""),
                "author": "",
                "created_at": item.get("generated_at", ""),
                "status": LEGACY,
                "data": {},
                "versions": [],
                "legacy": True,
            }
        docs.append(item)
    return docs


def save_docs(docs):
    DOCS_FILE.write_text(json.dumps(docs, indent=2), encoding="utf-8")


def get_doc(doc_id):
    for d in load_docs():
        if d["doc_id"] == doc_id:
            return d
    return None


def _store(doc):
    docs = load_docs()
    for i, d in enumerate(docs):
        if d["doc_id"] == doc["doc_id"]:
            docs[i] = doc
            break
    else:
        docs.insert(0, doc)
    save_docs(docs)


def _next_doc_id(docs):
    nums = []
    for d in docs:
        if d["doc_id"].startswith("SRD-"):
            try:
                nums.append(int(d["doc_id"][4:]))
            except ValueError:
                pass
    return f"SRD-{(max(nums) + 1 if nums else 1):03d}"


# ---------------------------------------------------------------- versions
def next_version(doc):
    versions = doc.get("versions", [])
    if not versions:
        return "1.0"
    major, minor = versions[-1]["version"].split(".")
    return f"{major}.{int(minor) + 1}"


def latest_version(doc):
    versions = doc.get("versions", [])
    return versions[-1] if versions else None


# ---------------------------------------------------------------- actions
def save_draft(doc_id, data, author):
    """Create a new document (doc_id None) or update the draft of an existing one."""
    if not (data.get("project_name") or "").strip():
        raise WorkflowError("Please enter a project name.")
    if doc_id is None:
        docs = load_docs()
        doc = {
            "doc_id": _next_doc_id(docs),
            "project_name": data["project_name"].strip(),
            "department": data.get("department", ""),
            "author": author,
            "created_at": _now(),
            "status": DRAFT,
            "data": data,
            "versions": [],
        }
    else:
        doc = get_doc(doc_id)
        if not doc:
            raise WorkflowError("Document not found.")
        if doc["author"] != author:
            raise WorkflowError("Only the author can edit this document.")
        if doc["status"] not in EDITABLE:
            raise WorkflowError(f"Document is '{doc['status']}' and cannot be edited.")
        doc["project_name"] = data["project_name"].strip()
        doc["department"] = data.get("department", "")
        doc["data"] = data
        doc["status"] = DRAFT  # editing after "Changes Requested" starts the next revision
    doc["updated_at"] = _now()
    _store(doc)
    return doc


def submit(doc_id, author, reviewer, approver):
    """Author assigns reviewer + approver and submits; creates a new version."""
    doc = get_doc(doc_id)
    if not doc:
        raise WorkflowError("Save the draft before submitting.")
    if doc["author"] != author:
        raise WorkflowError("Only the author can submit this document.")
    if doc["status"] not in EDITABLE:
        raise WorkflowError(f"Document is already '{doc['status']}'.")
    if not reviewer or not approver:
        raise WorkflowError("Select both a reviewer and an approver.")
    if reviewer == approver:
        raise WorkflowError("Reviewer and approver must be different people.")
    if author in (reviewer, approver):
        raise WorkflowError("The author cannot be the reviewer or approver.")
    version = next_version(doc)
    snapshot = copy.deepcopy(doc["data"])
    snapshot["version"] = version
    doc.setdefault("versions", []).append({
        "version": version,
        "submitted_at": _now(),
        "submitted_by": author,
        "reviewer": reviewer,
        "approver": approver,
        "status": IN_REVIEW,
        "data": snapshot,
        "review": None,
        "approval": None,
    })
    doc["status"] = IN_REVIEW
    doc["updated_at"] = _now()
    _store(doc)
    return doc


def _decide(doc_id, user, stage, decision, comments):
    doc = get_doc(doc_id)
    if not doc:
        raise WorkflowError("Document not found.")
    entry = latest_version(doc)
    if stage == "review":
        expected, person, key = IN_REVIEW, entry and entry["reviewer"], "review"
    else:
        expected, person, key = IN_APPROVAL, entry and entry["approver"], "approval"
    if doc["status"] != expected:
        raise WorkflowError(f"This document is '{doc['status']}', not awaiting {stage}.")
    if user != person:
        raise WorkflowError(f"Only {person} can record this {stage} decision.")
    if decision not in (APPROVE, REQUEST_CHANGES):
        raise WorkflowError("Invalid decision.")
    comments = (comments or "").strip()
    if decision == REQUEST_CHANGES and not comments:
        raise WorkflowError("Please add a comment explaining the changes required.")
    entry[key] = {"by": user, "decision": decision, "comments": comments, "date": _now()}
    if decision == REQUEST_CHANGES:
        new_status = CHANGES
    else:
        new_status = IN_APPROVAL if stage == "review" else APPROVED
    entry["status"] = new_status
    doc["status"] = new_status
    doc["updated_at"] = _now()
    _store(doc)
    return doc


def record_review(doc_id, user, decision, comments):
    return _decide(doc_id, user, "review", decision, comments)


def record_approval(doc_id, user, decision, comments):
    return _decide(doc_id, user, "approval", decision, comments)


def tasks_for(user):
    """Documents waiting for this user to review or approve."""
    out = []
    for d in load_docs():
        v = latest_version(d)
        if not v:
            continue
        if d["status"] == IN_REVIEW and v["reviewer"] == user:
            out.append((d, "Review"))
        elif d["status"] == IN_APPROVAL and v["approver"] == user:
            out.append((d, "Final Approval"))
    return out


# ---------------------------------------------------------------- document control block
def control_for(doc, entry=None):
    """Build the dict that srd_generator uses to fill the Document Control & Approval section.

    entry=None -> the in-progress draft; entry=<version> -> that submitted version.
    """
    versions = doc.get("versions", [])
    base = {"doc_id": doc["doc_id"], "created_date": doc.get("created_at", ""), "prepared_by": doc.get("author", "")}
    if entry is None:
        history = [_hist(v) for v in versions]
        base.update({
            "version": next_version(doc) if versions else "0.1",
            "status": doc["status"],
            "prepared_date": _now(),
            "reviewer": None, "reviewer_date": None,
            "approver": None, "approver_date": None,
            "review_decision": None, "review_comments": None,
            "approval_decision": None, "approval_comments": None,
            "history": history,
        })
        return base
    idx = versions.index(entry)
    rev, app = entry.get("review"), entry.get("approval")
    base.update({
        "version": entry["version"],
        "status": entry["status"],
        "prepared_date": entry["submitted_at"],
        "reviewer": entry["reviewer"],
        "reviewer_date": rev["date"] if rev else None,
        "approver": entry["approver"],
        "approver_date": app["date"] if app else None,
        "review_decision": rev["decision"] if rev else None,
        "review_comments": rev["comments"] if rev else None,
        "approval_decision": app["decision"] if app else None,
        "approval_comments": app["comments"] if app else None,
        "history": [_hist(v) for v in versions[: idx + 1]],
    })
    return base


def _hist(v):
    return {"version": v["version"], "reviewer": v["reviewer"], "approver": v["approver"], "status": v["status"]}

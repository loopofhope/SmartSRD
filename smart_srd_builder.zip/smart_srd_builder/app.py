import streamlit as st
from datetime import date

import workflow as wf
from srd_generator import build_srd, fmt_date
from ai_assistant import enhance_description, suggest_requirements, check_ollama
from document_viewer import render_preview
from pdf_preview import render_document, build_paged
import uuid
from pathlib import Path

st.set_page_config(page_title="Smart SRD Builder", page_icon="📝", layout="wide")

st.markdown("""
<style>
    .block-container {padding-top: 2rem; max-width: 1180px;}
    .hero {padding: 1.35rem 1.6rem; border-radius: 16px;
           background: linear-gradient(120deg,#102a43,#235789); color:white; margin-bottom:1rem;}
    .hero h1 {color:white; margin:0 0 .35rem 0;}
    .hero p {color:#e6f0fa; margin:0;}
    div[data-testid="stMetric"] {background:#f8fafc; padding:12px; border-radius:12px;}
</style>
""", unsafe_allow_html=True)

DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
PAGES = ["Create SRD", "My documents", "Review queue", "Document history", "About"]

# session-state key -> key in the saved data dict
TEXT_KEYS = {
    "f_project_name": "project_name", "f_department": "department", "f_owner": "project_owner",
    "f_stakeholders": "stakeholders", "f_description": "description", "f_objectives": "objectives",
    "f_business_need": "business_need", "f_scope_in": "scope_in", "f_scope_out": "scope_out",
    "f_assumptions": "assumptions", "f_dependencies": "dependencies", "f_risks": "risks",
    "f_acceptance": "acceptance", "functional": "functional_requirements",
    "nonfunctional": "nonfunctional_requirements", "f_glossary": "glossary",
}

FIG_DIR = Path(__file__).parent / "data" / "figures"
FIG_DIR.mkdir(parents=True, exist_ok=True)
DEFAULT_GLOSSARY = (
    "SRD: Software Requirements Document. Describes what a software solution must do and the constraints it must meet.\n"
    "FR: Functional Requirement. A statement of what the system must do.\n"
    "NFR: Non-Functional Requirement. A quality or constraint such as security, performance or usability."
)

for _k in TEXT_KEYS:
    st.session_state.setdefault(_k, "")
st.session_state.setdefault("f_date", date.today())
if not st.session_state.get("_init_glossary"):
    st.session_state["f_glossary"] = DEFAULT_GLOSSARY
    st.session_state["_init_glossary"] = True
st.session_state.setdefault("figures", [])
st.session_state.setdefault("fig_n", 0)
st.session_state.setdefault("f_target", None)
st.session_state.setdefault("active_doc", None)
st.session_state.setdefault("page", PAGES[0])


# ------------------------------------------------------------------ helpers
def collect_form():
    d = {dk: st.session_state.get(sk, "") for sk, dk in TEXT_KEYS.items()}
    d["prepared_by"] = st.session_state.get("user", "")
    d["project_date"] = (st.session_state.get("f_date") or date.today()).isoformat()
    target = st.session_state.get("f_target")
    d["target_date"] = target.isoformat() if target else ""
    d["figures"] = [{"file": f["file"], "caption": st.session_state.get(f"figcap_{f['id']}", f["caption"])}
                    for f in st.session_state.get("figures", [])]
    return d


def load_form(data):
    for sk, dk in TEXT_KEYS.items():
        st.session_state[sk] = data.get(dk, "")
    st.session_state["f_date"] = date.fromisoformat(data["project_date"]) if data.get("project_date") else date.today()
    st.session_state["f_target"] = date.fromisoformat(data["target_date"]) if data.get("target_date") else None
    st.session_state["figures"] = [{"id": uuid.uuid4().hex[:8], "file": f["file"], "caption": f.get("caption", "")}
                                   for f in data.get("figures", [])]


def flash(kind, msg):
    st.session_state["flash"] = (kind, msg)


# ---- callbacks (they run before the next render, so they may set widget values safely)
def cb_new():
    load_form({})
    st.session_state["f_glossary"] = DEFAULT_GLOSSARY
    st.session_state.active_doc = None
    st.session_state.pop("sel_reviewer", None)
    st.session_state.pop("sel_approver", None)


def cb_open(doc_id):
    doc = wf.get_doc(doc_id)
    load_form(doc["data"])
    st.session_state.active_doc = doc_id
    st.session_state.page = "Create SRD"
    last = wf.latest_version(doc)
    if last:  # reuse the previous reviewer/approver (author can change them)
        st.session_state["sel_reviewer"] = last["reviewer"]
        st.session_state["sel_approver"] = last["approver"]


def cb_remove_fig(fig_id):
    st.session_state["figures"] = [f for f in st.session_state["figures"] if f["id"] != fig_id]


def cb_enhance():
    d = collect_form()
    result, note = enhance_description(d["description"], d["project_name"])
    if result:
        st.session_state.f_description = result
    st.session_state["ai_note"] = ("success" if result else "warning", note)


def cb_suggest(kind):
    result, note = suggest_requirements(collect_form(), kind)
    if result:
        st.session_state["functional" if kind == "functional" else "nonfunctional"] = result
    st.session_state["ai_note"] = ("success" if result else "warning", note)


def cb_save():
    try:
        doc = wf.save_draft(st.session_state.active_doc, collect_form(), st.session_state.user)
        st.session_state.active_doc = doc["doc_id"]
        flash("success", f"Draft saved as {doc['doc_id']}.")
    except wf.WorkflowError as exc:
        flash("error", str(exc))


def cb_submit():
    try:
        doc = wf.save_draft(st.session_state.active_doc, collect_form(), st.session_state.user)
        st.session_state.active_doc = doc["doc_id"]
        doc = wf.submit(doc["doc_id"], st.session_state.user,
                        st.session_state.get("sel_reviewer"), st.session_state.get("sel_approver"))
        v = wf.latest_version(doc)
        flash("success", f"{doc['doc_id']} v{v['version']} submitted. {v['reviewer']} will review it next.")
    except wf.WorkflowError as exc:
        flash("error", str(exc))


# ------------------------------------------------------------------ header + sidebar
st.markdown("""
<div class="hero">
  <h1>📝 Smart SRD Builder</h1>
  <p>Create, review and approve Software Requirements Documents with a built-in approval record.</p>
</div>
""", unsafe_allow_html=True)

users = wf.load_users()
names = [u["name"] for u in users]
titles = {u["name"]: u.get("title", "") for u in users}

with st.sidebar:
    st.title("Workspace")
    st.selectbox("Signed in as", names, key="user",
                 format_func=lambda n: f"{n} ({titles[n]})" if titles.get(n) else n)
    st.caption("Prototype: pick who you are. Real sign-in is a next step.")
    user = st.session_state.user
    pending = len(wf.tasks_for(user))
    st.radio("Navigate", PAGES, key="page")
    to_fix = [d for d in wf.load_docs() if d.get("author") == user and d["status"] == wf.CHANGES]
    if to_fix:
        st.error(f"{len(to_fix)} of your document(s) need changes. Open **My documents**.")
    if pending:
        st.warning(f"{pending} document(s) waiting for you in **Review queue**")
    with st.expander("Add a person"):
        new_name = st.text_input("Name", key="new_user_name")
        new_title = st.text_input("Title / role", key="new_user_title")
        if st.button("Add person"):
            try:
                wf.add_user(new_name, new_title)
                st.rerun()
            except wf.WorkflowError as exc:
                st.error(str(exc))
    st.divider()
    ollama_ok, ollama_message = check_ollama()
    (st.success if ollama_ok else st.info)("Local AI is available" if ollama_ok else "Local AI not detected")
    st.caption(ollama_message)

if "flash" in st.session_state:
    kind, msg = st.session_state.pop("flash")
    getattr(st, kind)(msg)

page = st.session_state.page
docs = wf.load_docs()


def download_btn(label, doc, entry, key, primary=False):
    if entry is None:
        data, control = doc["data"], wf.control_for(doc)
        name = f"{doc['doc_id']}_draft.docx"
    else:
        data, control = entry["data"], wf.control_for(doc, entry)
        name = f"{doc['doc_id']}_v{entry['version']}_{entry['status'].replace(' ', '')}.docx"
    st.download_button(label, data=build_srd(data, control), file_name=name, mime=DOCX_MIME,
                       key=key, type="primary" if primary else "secondary")


def show_doc(doc, entry, key):
    """Show the real Word document (as PDF pages) with .docx / .pdf downloads; fall back to the simple view."""
    if entry is None:
        data, control, base = doc["data"], wf.control_for(doc), f"{doc['doc_id']}_draft"
    else:
        data, control = entry["data"], wf.control_for(doc, entry)
        base = f"{doc['doc_id']}_v{entry['version']}_{entry['status'].replace(' ', '')}"
    if not render_document(build_paged(data, control), key, base):
        render_preview(data, control)


# ------------------------------------------------------------------ Create SRD (author)
if page == "Create SRD":
    doc = wf.get_doc(st.session_state.active_doc) if st.session_state.active_doc else None
    editable = doc is None or (doc["status"] in wf.EDITABLE and doc["author"] == user)

    top1, top2 = st.columns([4, 1])
    if doc:
        top1.markdown(f"**{doc['doc_id']}**  •  Status: **{doc['status']}**  •  Author: {doc['author']}")
    else:
        top1.markdown("**New document** (not saved yet)")
    top2.button("Start new SRD", on_click=cb_new, width="stretch")

    if doc and not editable:
        st.info(f"This document is **{doc['status']}** (author: {doc['author']}) and is read-only for you.")
        show_doc(doc, wf.latest_version(doc), f"ro_{doc['doc_id']}")
        st.stop()

    if doc and doc["status"] in wf.EDITABLE and wf.latest_version(doc):
        last = wf.latest_version(doc)
        for key, label in (("review", "Reviewer"), ("approval", "Approver")):
            rec = last.get(key)
            if rec and rec["decision"] == wf.REQUEST_CHANGES:
                st.warning(f"**Changes requested by {label} {rec['by']} on v{last['version']}:** {rec['comments']}")

    st.subheader("1. Project information")
    c1, c2 = st.columns(2)
    with c1:
        st.text_input("Project name *", key="f_project_name", placeholder="e.g. Employee Leave Management System")
        st.text_input("Department", key="f_department", placeholder="e.g. Human Resources")
        st.text_input("Project owner / manager", key="f_owner", placeholder="Name or role")
        st.text_input("Prepared by", value=user, disabled=True, help="Taken from the signed-in user.")
    with c2:
        st.date_input("Document date", key="f_date")
        st.date_input("Target completion date", key="f_target")
        st.text_input("Key stakeholders", key="f_stakeholders", placeholder="e.g. HR, IT, Finance")
        st.text_input("Document version", value=doc and wf.next_version(doc) if doc and wf.latest_version(doc) else "Assigned on submission",
                      disabled=True)
    st.text_area("Project description", key="f_description", height=110,
                 placeholder="Describe the problem, proposed solution and who will use it.")
    st.text_area("Project objectives", key="f_objectives", height=90, placeholder="One objective per line")
    st.text_area("Business need / problem statement", key="f_business_need", height=90)

    st.divider()
    st.subheader("2. Optional AI assistance")
    st.caption("Uses local Ollama if available. Suggestions are drafts, so review them before submitting.")
    st.button("Enhance project description", on_click=cb_enhance)
    a, b = st.columns(2)
    a.button("Suggest functional requirements", on_click=cb_suggest, args=("functional",), width="stretch")
    b.button("Suggest non-functional requirements", on_click=cb_suggest, args=("nonfunctional",), width="stretch")
    if "ai_note" in st.session_state:
        k, m = st.session_state.pop("ai_note")
        getattr(st, k)(m)
    st.text_area("Functional requirements (one per line)", key="functional", height=140,
                 placeholder="The system shall ...")
    st.text_area("Non-functional requirements (one per line)", key="nonfunctional", height=120,
                 placeholder="The system shall ...")

    st.divider()
    st.subheader("3. Additional sections (optional)")
    with st.expander("Scope, assumptions, dependencies, risks and acceptance criteria"):
        st.text_area("In scope", key="f_scope_in")
        st.text_area("Out of scope", key="f_scope_out")
        st.text_area("Assumptions", key="f_assumptions")
        st.text_area("Dependencies", key="f_dependencies")
        st.text_area("Risks and constraints", key="f_risks")
        st.text_area("Acceptance criteria", key="f_acceptance")
    with st.expander("Figures and glossary"):
        st.markdown("**Figures** (diagrams, screenshots, mock-ups). They appear in section 10 and in the List of Figures.")
        ups = st.file_uploader("Add figures", type=["png", "jpg", "jpeg"], accept_multiple_files=True,
                               key=f"figup_{st.session_state.fig_n}")
        if ups:
            for up in ups:
                fname = f"{uuid.uuid4().hex}{Path(up.name).suffix.lower()}"
                (FIG_DIR / fname).write_bytes(up.getvalue())
                st.session_state.figures.append({"id": uuid.uuid4().hex[:8], "file": fname,
                                                 "caption": Path(up.name).stem.replace("_", " ").replace("-", " ")})
            st.session_state.fig_n += 1
            st.rerun()
        for fig in st.session_state.figures:
            fc1, fc2, fc3 = st.columns([1, 4, 1])
            if (FIG_DIR / fig["file"]).is_file():
                fc1.image(str(FIG_DIR / fig["file"]), width=90)
            fc2.text_input("Caption", value=fig["caption"], key=f"figcap_{fig['id']}")
            fc3.button("Remove", key=f"rm_{fig['id']}", on_click=cb_remove_fig, args=(fig["id"],))
        st.markdown("**Glossary** (one per line as `Term: definition`)")
        st.text_area("Glossary", key="f_glossary", height=140, label_visibility="collapsed")

    st.divider()
    st.subheader("4. Save draft")
    s1, s2 = st.columns(2)
    s1.button("Save draft", on_click=cb_save, width="stretch")
    if doc:
        with s2:
            download_btn("⬇ Download current draft (.docx)", doc, None, "dl_draft")
    if doc and st.toggle("Preview saved draft as a document", key="preview_draft"):
        show_doc(doc, None, f"draft_{doc['doc_id']}")

    st.divider()
    st.subheader("5. Assign reviewer and approver, then submit")
    others = [n for n in names if n != user]
    r1, r2 = st.columns(2)
    r1.selectbox("Reviewer", [""] + others, key="sel_reviewer",
                 format_func=lambda n: "Select reviewer…" if not n else f"{n} ({titles[n]})" if titles.get(n) else n)
    r2.selectbox("Approver", [""] + others, key="sel_approver",
                 format_func=lambda n: "Select approver…" if not n else f"{n} ({titles[n]})" if titles.get(n) else n)
    st.caption("Reviewer and approver must be different people, and neither can be the author. "
               "Submitting saves your draft, locks it, and creates the next version.")
    st.button("Submit for review", type="primary", on_click=cb_submit, width="stretch")


# ------------------------------------------------------------------ My documents (author)
elif page == "My documents":
    st.subheader("My documents")
    mine = [d for d in docs if d.get("author") == user]
    if not mine:
        st.info("You haven't created any documents yet.")
    for d in mine:
        with st.container(border=True):
            left, right = st.columns([3, 2])
            v = wf.latest_version(d)
            left.markdown(f"**{d['project_name']}**  \n{d['doc_id']} • Status: **{d['status']}**"
                          + (f" • Latest version: {v['version']}" if v else ""))
            if v:
                left.caption(f"Reviewer: {v['reviewer']} • Approver: {v['approver']}")
            with right:
                if d["status"] in wf.EDITABLE:
                    st.button("Open for editing & resubmit" if d["status"] == wf.CHANGES else "Open for editing", key=f"open_{d['doc_id']}", on_click=cb_open, args=(d["doc_id"],))
                if d["status"] == wf.APPROVED:
                    download_btn("⬇ Download final approved SRD", d, v, f"final_{d['doc_id']}", primary=True)
            if d["status"] == wf.CHANGES and v:
                for key, label in (("review", "Reviewer"), ("approval", "Approver")):
                    rec = v.get(key)
                    if rec and rec["decision"] == wf.REQUEST_CHANGES:
                        st.warning(f"**{label} {rec['by']} requested changes on v{v['version']}:** {rec['comments']}  \n"
                                   "Click **Open for editing**, update the document, then **Submit for review** again "
                                   f"(it will become v{wf.next_version(d)}).")
            if not d.get("legacy") and st.toggle("View document", key=f"view_{d['doc_id']}"):
                show_doc(d, None if d["status"] == wf.DRAFT else v, f"my_{d['doc_id']}")


# ------------------------------------------------------------------ Review queue (reviewer / approver)
elif page == "Review queue":
    st.subheader("Review queue")
    tasks = wf.tasks_for(user)
    if not tasks:
        st.info("Nothing is waiting for you right now.")
    else:
        labels = {f"{d['doc_id']} – {d['project_name']} ({stage})": (d["doc_id"], stage) for d, stage in tasks}
        pick = st.selectbox("Select a document", list(labels))
        doc_id, stage = labels[pick]
        doc = wf.get_doc(doc_id)
        entry = wf.latest_version(doc)
        st.caption(f"Author: {doc['author']} • Version {entry['version']} • Submitted {fmt_date(entry['submitted_at'])}")
        if stage == "Final Approval" and entry["review"]:
            st.info(f"**Review by {entry['review']['by']}:** {entry['review']['decision']}"
                    + (f" — {entry['review']['comments']}" if entry["review"]["comments"] else ""))
        show_doc(doc, entry, f"rq_{doc_id}_{entry['version']}")

        st.divider()
        st.subheader(f"Your decision: {stage}")
        with st.form(f"decision_{doc_id}"):
            decision = st.radio("Decision", [wf.APPROVE, wf.REQUEST_CHANGES], horizontal=True)
            comments = st.text_area("Comments (required if requesting changes)")
            go = st.form_submit_button("Record decision", type="primary")
        if go:
            try:
                fn = wf.record_review if stage == "Review" else wf.record_approval
                updated = fn(doc_id, user, decision, comments)
                flash("success", f"Decision recorded. {updated['doc_id']} is now: {updated['status']}.")
                st.rerun()
            except wf.WorkflowError as exc:
                st.error(str(exc))


    waiting = []
    for d in docs:
        v = wf.latest_version(d)
        if v and user in (v["reviewer"], v["approver"]) and (d, ) and d["status"] != wf.APPROVED \
                and d["doc_id"] not in [t[0]["doc_id"] for t in tasks]:
            waiting.append((d, v))
    if waiting:
        st.divider()
        st.markdown("**Documents you are assigned to that need no action from you right now**")
        for d, v in waiting:
            note = {wf.CHANGES: f"Changes requested. Waiting for {d['author']} to revise and resubmit.",
                    wf.IN_REVIEW: f"Waiting for reviewer {v['reviewer']}.",
                    wf.IN_APPROVAL: f"Waiting for approver {v['approver']}.",
                    wf.DRAFT: f"Being revised by {d['author']}."}.get(d["status"], d["status"])
            st.write(f"- **{d['doc_id']} – {d['project_name']}** (v{v['version']}): {note}")


# ------------------------------------------------------------------ Document history (everyone)
elif page == "Document history":
    st.subheader("Document history")
    if not docs:
        st.info("No documents yet. Create your first SRD from the Create SRD page.")
    for d in docs:
        with st.expander(f"{d['doc_id']} – {d['project_name']}  •  {d['status']}"):
            st.caption(f"Department: {d.get('department') or '—'} • Author: {d.get('author') or '—'} "
                       f"• Created: {fmt_date(d.get('created_at'), '—')}")
            if not d["versions"]:
                st.write("No versions submitted yet." if not d.get("legacy") else "Record from the earlier prototype (metadata only).")
            for v in reversed(d["versions"]):
                with st.container(border=True):
                    st.markdown(f"**Version {v['version']}** — {v['status']}  \n"
                                f"Submitted by {v['submitted_by']} on {fmt_date(v['submitted_at'])}  \n"
                                f"Reviewer: {v['reviewer']} • Approver: {v['approver']}")
                    for label, key in (("Review", "review"), ("Final approval", "approval")):
                        rec = v.get(key)
                        if rec:
                            st.write(f"- **{label}:** {rec['decision']} by {rec['by']} on {fmt_date(rec['date'])}"
                                     + (f" — {rec['comments']}" if rec["comments"] else ""))
                    is_final = v["status"] == wf.APPROVED
                    download_btn("⬇ Download final approved SRD" if is_final else f"⬇ Download v{v['version']} (.docx)",
                                 d, v, f"hist_{d['doc_id']}_{v['version']}", primary=is_final)
                    if st.toggle("View document", key=f"hv_{d['doc_id']}_{v['version']}"):
                        show_doc(d, v, f"hview_{d['doc_id']}_{v['version']}")


# ------------------------------------------------------------------ About
elif page == "About":
    st.subheader("About Smart SRD Builder")
    st.markdown("""
    A local-first prototype for creating controlled Software Requirements Documents.

    **Workflow**
    1. The author creates and edits the SRD.
    2. The author selects a reviewer and an approver and submits (this creates a version).
    3. The reviewer checks a read-only preview and approves or requests changes.
    4. The approver gives final approval or sends it back.
    5. If changes are requested, the author revises and resubmits as the next version. Earlier versions and decisions are kept.

    Names, dates, decisions, comments and version history are written into the Word document automatically.

    **Privacy note:** Everything is stored on this computer in the `data` folder. If you enable a local Ollama model,
    prompts are sent to that local service. Do not enter confidential information into an unapproved AI service.
    """)

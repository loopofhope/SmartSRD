# Smart SRD Builder

A local-first Streamlit prototype that captures project information, optionally uses local AI through Ollama, and generates an editable Microsoft Word (`.docx`) Software Requirements Document.

## Features

- Simple project information form
- Professional SRD Word document with cover page, document control, headings, requirements tables and approval table
- Bracketed prompts for information the user has not supplied
- Optional local AI description enhancement and requirement suggestions using Ollama
- Local JSON history of generated document metadata
- No API key required

## Requirements

- Windows 10/11
- Python 3.10 or newer
- Microsoft Word (or another `.docx` editor) to edit the output
- Optional: Ollama + a local model for AI features

## Quick start on Windows

1. Extract the ZIP to a folder, for example `C:\SmartSRDBuilder`.
2. Install Python 3.10+ from https://www.python.org/downloads/ (enable **Add Python to PATH**) or use the Python launcher `py`.
3. Double-click `run_windows.bat`.
4. The script creates a virtual environment, installs dependencies and starts Streamlit.
5. Your browser should open at `http://localhost:8501`.

If the browser does not open, copy `http://localhost:8501` into your browser.

### Manual setup

Open Command Prompt in the project folder:

```bat
py -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

## Viewing the document in the browser

Reviewers and approvers see the real Word document (as PDF pages) inside the app, with **Download Word** and **Download PDF** buttons. This needs a converter: **Microsoft Word** (used automatically on Windows) or free **LibreOffice** (https://www.libreoffice.org/). If neither is found, the app shows a simplified view and tells you what to install.

## Optional free/local AI setup with Ollama

The core app and Word generation work without AI. For local AI assistance:

1. Install Ollama for Windows: https://ollama.com/download
2. Open a new Command Prompt and run:

```bat
ollama pull llama3.2
```

3. Ensure Ollama is running. Then refresh the Smart SRD Builder page.
4. Use **Enhance project description**, **Suggest functional requirements** or **Suggest non-functional requirements**.

The app connects to Ollama at `http://localhost:11434`. The default model is `llama3.2`. To use another installed model, change `DEFAULT_MODEL` in `ai_assistant.py` to its exact Ollama model name.

Local AI performance depends on your laptop's RAM and processor. If the model is unavailable or too slow, skip AI and use the normal form and Word generation.

## Review and approval workflow

1. **Author** creates the SRD, saves a draft, picks a **reviewer** and an **approver**, and submits (creates version 1.0).
2. **Reviewer** opens **Review queue**, checks the read-only preview and records *Approved* or *Changes Requested* with comments.
3. **Approver** does the same for final approval.
4. If changes are requested, the author reopens the draft from **My documents**, edits, and resubmits as the next version (1.1, 1.2...). Earlier versions and their decisions stay in **Document history**.
5. Once approved, the author (or anyone) can download the final Word file.

Names, dates, decisions, comments, version history and final status are written into the **Document Control & Approval** page of the .docx automatically.

Notes: "Signed in as" is a prototype user picker, not real authentication. Add people in the sidebar or in `data/users.json`. Delete `data/projects.json` if you want to start clean (old prototype records appear as "Generated (legacy)").

## How to use

1. Open **Create SRD**.
2. Enter at least a project name.
3. Fill in any known project information and click **Save project details**.
4. Optionally use AI to enhance the description or suggest requirements.
5. Review and edit all AI suggestions.
6. Fill optional scope, assumptions, dependencies, risks and acceptance criteria.
7. Click **Generate editable SRD (.docx)**.
8. Download the Word file and replace remaining bracketed prompts.

## Project structure

```text
smart_srd_builder/
├── app.py
├── srd_generator.py
├── ai_assistant.py
├── workflow.py          (users, versions, review/approval transitions)
├── pdf_preview.py       (DOCX -> PDF -> page images shown in the browser)
├── document_viewer.py   (read-only preview for reviewers/approvers)
├── requirements.txt
├── run_windows.bat
├── README.md
└── data/
    ├── projects.json   (documents, versions, decisions; created automatically)
    └── users.json      (people list; created automatically, edit or add in the sidebar)
```

## Prototype limitations / sensible next steps

- History currently stores document metadata, not the generated files themselves.
- Generated documents are downloaded to the user's chosen location; edits made in Word are not synced back into the app.
- The current prototype uses a standard SRD structure, not an organization's approved template.
- AI suggestions are drafts, not verified requirements. A business owner or analyst must validate them.
- Before internal production use, add authentication, access controls, approved storage, audit logs, backup, and company-approved AI/privacy controls.
- Do not send confidential, personal or regulated company data to an AI service unless your organization has approved that service and its data-handling terms.

## Troubleshooting

**`py` is not recognized:** reinstall Python and enable the Python Launcher / PATH option, or use `python` in place of `py`.

**Port 8501 is busy:**
```bat
streamlit run app.py --server.port 8502
```

**Ollama not detected:** verify Ollama is installed and running, then run `ollama list`. The app still generates Word documents without Ollama.

**Word document generation fails:** run `pip install --upgrade python-docx` inside the activated virtual environment.
